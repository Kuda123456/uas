import json

import requests
from flask import Flask, redirect, render_template, request, url_for

app = Flask(__name__)

global appType 

appType = 'Web Service'

@app.route('/')
def index():
    return render_template('index.html', appType=appType)

@app.route('/createcar')
def createcar():
    return render_template('createcar.html', appType=appType)

@app.route('/createcarsave',methods=['GET','POST'])
def createcarsave():
    fName = request.form['carName']
    fBrand = request.form['carBrand']
    fModel = request.form['carModel']
    fPrice = request.form['carPrice']

    datacar = {
        "carname" : fName,
        "carbrand" : fBrand,
        "carmodel" : fModel,
        "carprice" : fPrice
    }
    
    datacar_json = json.dumps(datacar)

    alamatserver = "http://localhost:5055/cars/"
    
    headers = {'Content-Type':'application/json', 'Accept':'text/plain'}

    kirimdata = requests.post(alamatserver, data=datacar_json, headers=headers)

    return redirect(url_for('readcar'))


@app.route('/readcar')
def readcar():
    alamatserver = "http://localhost:5055/cars"
    datas = requests.get(alamatserver)

    rows = json.loads(datas.text)

    return render_template('readcar.html', rows=rows, appType=appType)

@app.route('/updatecar')
def updatecar():
    return render_template('updatecar.html', appType=appType)

@app.route('/updatecarsave', methods=['POST'])
def updatecarsave():
    fId = request.form['id']
    fName = request.form['carName']
    fBrand = request.form['carBrand']
    fModel = request.form['carModel']
    fPrice = request.form['carPrice']

    # Prepare the car data to be updated
    datacar = {
        "id": fId,
        "carname": fName,
        "carbrand": fBrand,
        "carmodel": fModel,
        "carprice": fPrice
    }
    datacar_json = json.dumps(datacar)
    headers = {'Content-Type': 'application/json', 'Accept': 'text/plain'}

    # Send a PUT request to the external API to update the car
    response = requests.put(f"http://localhost:5055/cars/", data=datacar_json, headers=headers)

    if response.status_code == 200:
        return redirect(url_for('readcar'))
    else:
        # Handle error (you might want to show an error message)
        return f"Error: {response.status_code}"

@app.route('/deletecar')
def deletecar():
    return render_template('deletecar.html', appType=appType)

@app.route('/deletecarsave', methods=['GET','POST'])
def deletecarsave():
    fName = request.form['carName']

    datacar = {
        "carname" : fName
    }
    
    datacar_json = json.dumps(datacar)

    alamatserver = "http://localhost:5055/cars/"
    
    headers = {'Content-Type':'application/json', 'Accept':'text/plain'}

    kirimdata = requests.delete(alamatserver, data=datacar_json, headers=headers)

    return redirect(url_for('readcar'))

@app.route('/searchcar', methods=['GET', 'POST'])
def searchcar():
    if request.method == 'POST':
        search_query = request.form.get('searchQuery', '').strip()
        
        # Send a GET request to the server's API to fetch cars data
        alamatserver = "http://localhost:5055/cars"
        params = {'searchQuery': search_query}  # Pass the search query to the server
        try:
            response = requests.get(alamatserver, params=params)
            response.raise_for_status()  # Raise an exception if there's an error
            cars_data = response.json() if response.text else []
        except requests.exceptions.RequestException as e:
            print(f"Error: {e}")
            cars_data = []

        # Filter results based on the search query (e.g., name, brand, model)
        results = [car for car in cars_data if search_query.lower() in car['carname'].lower() or
                                                search_query.lower() in car['carbrand'].lower() or
                                                search_query.lower() in car['carmodel'].lower()]

        return render_template('searchcar.html', rows=results, search_query=search_query, appType=appType)
    
    return render_template('searchcar.html', appType=appType)

if __name__ == '__main__':
    
    app.run(
        host = '0.0.0.0',
        debug = 'True'
        )