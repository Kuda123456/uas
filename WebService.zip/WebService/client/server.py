from flask import Flask, jsonify, request

app = Flask(__name__)

cars = []

@app.route('/cars', methods=['GET'])
def get_cars():
    return jsonify(cars)

@app.route('/cars', methods=['POST'])
def add_car():
    car = request.json
    cars.append(car)
    return jsonify({"message": "Car added successfully"}), 201

if __name__ == '__main__':
    app.run(host='localhost', port=5055, debug=True)

